# Code of Conduct

We obey the [Go Community Code of Conduct](https://go.dev/conduct).
