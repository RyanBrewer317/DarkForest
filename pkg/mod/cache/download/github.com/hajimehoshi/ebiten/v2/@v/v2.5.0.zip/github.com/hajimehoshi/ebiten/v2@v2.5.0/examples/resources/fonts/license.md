# License

## mplus-1p-regular.ttf

```
M+ FONTS                                Copyright (C) 2002-2015 M+ FONTS PROJECT

-

LICENSE_E




These fonts are free software.
Unlimited permission is granted to use, copy, and distribute them, with
or without modification, either commercially or noncommercially.
THESE FONTS ARE PROVIDED "AS IS" WITHOUT WARRANTY.


http://mplus-fonts.sourceforge.jp/mplus-outline-fonts/
```

## PressStart2P-vaV7.ttf

```
Copyright (c) 2011, Cody "CodeMan38" Boisclair (cody@zone38.net),
with Reserved Font Name "Press Start".

This Font Software is licensed under the SIL Open Font License, Version 1.1.
```
