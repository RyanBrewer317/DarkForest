package main

func Foo() vec2 {
	x := true
	if x {
		return vec2(0)
	} else {
		return vec2(1)
	}
}
