package main

func Foo(foo vec2) vec4 {
	return vec4(0)
}
