package main

func Foo(x vec2) vec2 {
	v := vec2(0)
	if v := vec2(1); v.x == 1 {
		return v
	}
	return v
}
