package main

func Foo() vec2 {
	l0 := 0
	l0++
	l1 := 1
	l1--
	return vec2(l0, l1)
}
