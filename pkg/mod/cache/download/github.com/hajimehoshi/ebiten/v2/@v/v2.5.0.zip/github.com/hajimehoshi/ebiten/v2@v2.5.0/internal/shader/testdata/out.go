package main

func Foo() (a float, b [4]float, c vec4) {
	return
}
