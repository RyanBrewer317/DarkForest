package main

func Foo(foo vec2) vec4 {
	r := vec4(0.0) * vec4(0.0)
	return r
}
