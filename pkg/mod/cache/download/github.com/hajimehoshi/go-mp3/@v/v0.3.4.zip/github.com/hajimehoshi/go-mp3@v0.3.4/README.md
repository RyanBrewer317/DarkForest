# go-mp3

[![GoDoc](https://godoc.org/github.com/hajimehoshi/go-mp3?status.svg)](http://godoc.org/github.com/hajimehoshi/go-mp3)

An MP3 decoder in pure Go based on [PDMP3](https://github.com/technosaurus/PDMP3).

[Slide at golang.tokyo #11](https://docs.google.com/presentation/d/e/2PACX-1vTTXf-LWNRvMVGQ7GI4Wh8EKohot_9CMtlF4dswpYGpuYKOek5NeNP-_QZnNcRFZp9Cwm0pCcykjqDN/pub?start=false&loop=false&delayms=3000)
